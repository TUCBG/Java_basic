package practice;

public class me {

	public static void main(String[] args) {
		System.out.println("나의 이름은 최부건입니다.");
		System.out.println("나의 성별은 남성입니다.");
		System.out.println("나는 부산에 살고 있습니다.");
		System.out.println("나는 25살입니다.");
	}

}
