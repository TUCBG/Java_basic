package javabasic;

public class Hi {

	public static void main(String[] args) {
		// 나의 첫 자바 프로그램
		System.out.println("hello");
		System.out.print("hello!!!!");
	}

}
