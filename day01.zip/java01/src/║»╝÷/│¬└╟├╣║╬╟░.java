package 변수;

import javax.swing.JFrame;

public class 나의첫부품 {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(300,300);
		f.setVisible(true);
		
		JFrame f2 = new JFrame();
		f2.setSize(500,500);
		f2.setVisible(true);
	}
}
