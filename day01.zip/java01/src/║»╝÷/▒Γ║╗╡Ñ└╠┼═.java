package 변수;

public class 기본데이터 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 100;
		double height = 122.2;
		char gender = '남';
		boolean food = true;	
		
		String name = "홍길동";
		
		System.out.println("나의 이름은 :" + name);
		System.out.println("내 나이는 : " + age);
		System.out.println("내 키는 : " + height);
		System.out.println("내 성별은 : " + gender);
		System.out.println("내가 밥을 먹었는지 : " + food);
		
		}

}
