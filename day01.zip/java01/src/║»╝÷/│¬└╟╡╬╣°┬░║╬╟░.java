package 변수;

import javax.swing.JOptionPane;

public class 나의두번째부품 {

	public static void main(String[] args) {
		String age = JOptionPane.showInputDialog("당신의 나이를 입력하세요. ");
		JOptionPane.showMessageDialog(null ,"당신의 나이는 " +  age);
	}

}
