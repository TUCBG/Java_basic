package 변수;

public class 친구정보 {

	public static void main(String[] args) {
		String name = "이형석";
		int age = 25;
		double height = 174.5;
		char gender = '남';
		
		System.out.println("내 친구의 이름은 " + name);
		System.out.println("내 친구의 나이는 " + age);
		System.out.println("내 친구의 키는" + height);
		System.out.println("내 친구의 성별은 " + gender);
		
	}

}
